package com.tweetApp.FSE.Model;


import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "Tweet")
public class Tweet {
	
	@DynamoDBHashKey
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@DynamoDBAttribute
	private String tweetDescription;

	@DynamoDBAttribute
	private String tweetTag;

	@DynamoDBAttribute
	private String Date;

	@DynamoDBAttribute
	private String email;

	@DynamoDBAttribute
	private char recordActive;
	
	@DynamoDBAttribute
	private List<Reply> reply;

	public void setReply(List<Reply> reply) {
		this.reply = reply;
	}

	public List<Reply> getReply() {
		return reply;
	}


	public String getTweetDescription() {
		return tweetDescription;
	}

	public void setTweetDescription(String tweetDescription) {
		this.tweetDescription = tweetDescription;
	}

	public String getTweetTag() {
		return tweetTag;
	}

	public void setTweetTag(String tweetTag) {
		this.tweetTag = tweetTag;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public char getRecordActive() {
		return recordActive;
	}

	public void setRecordActive(char recordActive) {
		this.recordActive = recordActive;
	}

	@Override
	public String toString() {
		return "Tweet [id=" + id + ", tweetDescription=" + tweetDescription + ", tweetTag=" + tweetTag + ", Date="
				+ Date + ", email=" + email + ", recordActive=" + recordActive + ", reply=" + reply
				+ "]";
	}

	

	
	

	

}
