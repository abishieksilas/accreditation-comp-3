package com.tweetApp.FSE.Model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "Reply")
public class Reply {

	@DynamoDBHashKey
	private int id;

	@DynamoDBAttribute	
	private String email;

	@DynamoDBAttribute	
	private int tweetId;

	@DynamoDBAttribute	
	private String replyDesc;

	@DynamoDBAttribute	
	private String date;
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getReplyDesc() {
		return replyDesc;
	}

	public void setReplyDesc(String replyDesc) {
		this.replyDesc = replyDesc;
	}

	public int getTweetId() {
		return tweetId;
	}

	public void setTweetId(int tweetId) {
		this.tweetId = tweetId;
	}
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Reply [id=" + id + ", email=" + email + ", tweetId=" + tweetId + ", replyDesc=" + replyDesc + ", date="
				+ date + "]";
	}

	
	

}
