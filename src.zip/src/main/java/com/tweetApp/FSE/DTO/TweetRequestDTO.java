package com.tweetApp.FSE.DTO;

public class TweetRequestDTO {

	private String tweetDesc;

	private String emailId;

	@Override
	public String toString() {
		return "TweetRequestDTO [tweetDesc=" + tweetDesc + ", emailId=" + emailId + "]";
	}

	public String getTweetDesc() {
		return tweetDesc;
	}

	public void setTweetDesc(String tweetDesc) {
		this.tweetDesc = tweetDesc;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

}
